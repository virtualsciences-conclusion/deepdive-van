# Assignment 2 - Cluster / cloud resilience

# Step 1 - Deploy an additional backend service on cluster 38
oc create deployment backend --image quay.io/skupper/hello-world-backend --replicas 1
skupper expose deployment/backend --port 8080

# Step 2 - Create a disaster and check if the application sill works
Option 1)
Aks the instructor to create a disaster.

Go to the web console; The frontend service should be talking to the backend service
Notice: The will be an other backend service name

Option 2)
Delete the link between site 1 and site 26
skupper delete link link 1

Delete the link between site 26 and site 38
skupper delete link link 1