

# Assignment 1 - Network resilience

## Step 1 - Create a skupper site with a console on cluster 1
> Execute commands on cluster 1

oc create namespace black-north
oc config set-context --current --namespace=black-north

skupper init --enable-console --enable-flow-collector --console-user admin --console-password admin --site-name north
skupper status

Check the console using the url provided by the skupper init command output
Log into the console with user admin and password admin

## Step 2 - Create a skupper site on cluster 26
> Execute commands on cluster 26

oc create namespace black-east
oc config set-context --current --namespace=black-east

skupper init --site-name east
skupper status

## Step 3 - Create a link between cluster 1 and cluster 26
> Execute commands on cluster 1

skupper token create c1.token

> Execute commands on cluster 26

skupper link create c1.token  --name north-east
skupper link status

Check the skupper web console if the two sites are connected
Notice: The skupper web console has some delay showing connection updates

## Step 4 Create a skupper site on cluster 38
> Make sure you are logged in cluster 38

oc create namespace black-south
oc config set-context --current --namespace=black-south

skupper init  --site-name south
skupper status

## Step 5 - Create a link between cluster 26 and cluster 38
> Execute commands on cluster 26

skupper token create c26.token

> Execute commands on cluster 38

skupper link create c26.token --name east-south
skupper link status

Check the skupper web console if the two sites are connected
Notice: The skupper web console has some delay showing connection updates

## Step 6 - Complete the VAN by creating a link between cluster 38 and cluster 1
> Execute commands on cluster 38

skupper token create c38.token

> Execute commands on cluster 1

skupper link create c38.token --name south-north
skupper link status

Check the skupper web console if the two sites are connected. At this point in time, all sites are connected to each other. 
Notice: The skupper web console has some delay showing connection updates

# Step 7 - Deploy the backend application and expose the service
> Use cluster 26

oc create deployment backend --image quay.io/skupper/hello-world-backend --replicas 1
skupper expose deployment/backend --port 8080 

# Step 8 - Deploy the frontend application
> Use cluster 1

oc create deployment frontend --image quay.io/skupper/hello-world-frontend
oc expose deployment frontend --port 8080 --type LoadBalancer
oc get service/frontend

Go to the web console; The frontend service should be talking to the backend service 

# Step 9 - Create a disaster and check if the application sill works
Option 1)
Aks the instructor to create a disaster.

Go to the web console; The frontend service should be talking to the backend service 
Notice: The will be an other backend service name

Option 2)
Delete the link between site 1 and site 26
skupper delete link link 1
