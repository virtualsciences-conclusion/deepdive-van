# General information

Cluster urls  
https://console-openshift-console.apps.vs-rhdd-01-cluster.vs-azure-01.nl  
https://console-openshift-console.apps.vs-rhdd-26-cluster.vs-azure-01.nl  
https://console-openshift-console.apps.vs-rhdd-38-cluster.vs-azure-01.nl

(!) Be very precise to avoid interfering with other teams

# Install skupper CLI
curl https://skupper.io/install.sh | sh

For windows or mac see: https://skupper.io/install/index.html

# Validate skupper installed
skupper version

    $ skupper version
    client version                 1.8.3
    transport version              not-found
    controller version             not-found
    config-sync version            not-found
    flow-collector version         not-found

## Log into the all the clusters
> For each cluster 
> - open a terminal
> - set correct kube config
> - login with the token from OpenShift

### Terminal 1 - Log into cluster 01
export KUBECONFIG=$HOME/.kube/c1.config  
Get token and log in command from OpenShift web console (see urls in general section)
oc login --token=[your token] --server=https://api.vs-rhdd-01-cluster.vs-azure-01.nl:6443

### Terminal 2 - Log into cluster 26
export KUBECONFIG=$HOME/.kube/c26.config  
Get token and log in command from OpenShift web console (see urls in general section)
oc login --token=[your token] --server=https://api.vs-rhdd-26-cluster.vs-azure-01.nl:6443

### Terminal 3 - Log into cluster 38
export KUBECONFIG=$HOME/.kube/c38.config  
Get token and log in command from OpenShift web console (see urls in general section)
oc login --token=[your token] --server=https://api.vs-rhdd-38-cluster.vs-azure-01.nl:6443




