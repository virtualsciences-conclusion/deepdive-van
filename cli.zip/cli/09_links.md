Red Hat Service Interconnect overview video
https://www.youtube.com/watch?v=-l6DOoLTFII

Red Hat Service Interconnect Demo One
https://www.youtube.com/watch?v=M1PYQssLKRw

Red Hat Service Interconnect Demo Two
https://www.youtube.com/watch?v=n_ucFQBpkp4

Red Hat Service Interconnect 1.8
https://docs.redhat.com/en/documentation/red_hat_service_interconnect/1.8

10
